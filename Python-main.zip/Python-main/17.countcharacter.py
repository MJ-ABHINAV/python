import math
a=input("Enter a string: ")
b=input("enter a character: ")
s=a.count(b)
print("count is ",s)
