string=input("Enter the string to be reversed: ")
s=string[-1::-1]
print("The reverse is: ",s)

             
