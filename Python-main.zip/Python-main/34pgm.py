p=int(input('enter the % of marks'))
if p>=95:
    print('grade s')
elif p>=90:
    print('grade A+')
elif p>=80:
    print('grade A')
elif p>=75:
    print('grade B+')
elif p>=70:
    print('grade B')
else:
    print('you are failed! sorry')
