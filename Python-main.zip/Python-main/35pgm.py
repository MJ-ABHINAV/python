num=int(input('enter the number'))
print('even' if not num%2 else 'odd')
l=['akhil','albert','frestin']
item=input('enter an item to search')
print('available' if item.lower() in l else 'not available')

