#!/usr/bin/env python3
s=input("Enter the String: ")
r=s.split(".")
print("The extension is: ", r[1])
         
