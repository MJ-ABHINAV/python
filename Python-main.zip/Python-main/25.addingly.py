s=input("Enter a string: ")
if(s.lower().endswith('ing')):
    s+='ly'
else:
    s+='ing'
print(s)
    
    
