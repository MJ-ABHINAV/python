a=int(input("Enter the first Number: "))
b=int(input("Enter the second Number: "))
c=int(input("Enter the third Number: "))
print("The largest of the three numbers = ", max(a,b,c))
