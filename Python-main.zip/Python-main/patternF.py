for i in range(5):
    for j in range(3):
        if j==0 or i==0 or i==2:
            print("*",end="")
    print("")
