#module to find area and volume of sphere
def area(r):
    print("The area of sphere = ",4*22/7*r*r)
def volume(r):
    print("The volume of sphere = ",(4/3)*(22/7)*r**3)
    
