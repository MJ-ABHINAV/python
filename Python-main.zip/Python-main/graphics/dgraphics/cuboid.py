#module to find area and volume of cuboid
def area(l,b,h):
    print("The area of cuboid = ",2*(l*b+b*h+l*h))
def volume(l,b,h):
    print("The volume of cuboid = ",l*b*h)
    
