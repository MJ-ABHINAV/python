#function for finding area and perimeter of rectangle
def area(a,b):
    print("Area of rectangle = ",a*b,"square centimetres")
def perimeter(a,b):
    print("Perimeter of rectangle = ",2*(a+b),"cms")
