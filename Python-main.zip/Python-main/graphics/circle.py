#function for finding area and perimeter of rectangle
def area(r):
    print("Area of the circle with radius",r,"=",(22/7)*r*r,"square centimetres")
def perimeter(r):
    print("Perimeter of the circle with radius",r,"=",2*(22/7)*r,"cms")    
