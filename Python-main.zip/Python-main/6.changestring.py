s=input("Enter the first string: ")
r=input("Enter the second string: ")
output=r[0]+s[1::]+ ' '+s[0]+r[1::]
print("New string is",output)
