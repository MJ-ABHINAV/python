d={'name':'akhil','rollno':9,'age':21,'10':'rollno'}
k=input('enter the key')
print('the giver key is already in dictionary:',k in d)
        
