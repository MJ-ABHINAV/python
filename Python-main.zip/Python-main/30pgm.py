d={1:'akhil',3:'mca',2:'mace',5:'mpv',4:'ktm'}
print('ascending order of keys:',sorted(d))
print('descending order of keys:',sorted(d,reverse=True))
print('ascending order of values:',sorted(d.values()))
print('descending  order of values:',sorted(d.values(),reverse=True))
print('ascending order of both with respect to keys:',sorted(d.items()))
print('descending order of both with respect to keys:',sorted(d.items(),reverse=True))
