<<<<<<< HEAD
for i in range(7):
    for j in range(5):
        if j==0 or j==3 or i==3 or i==0:
            print("*",end="")
        else:
            print(end=" ")   
    print("")
=======
for i in range(5):
    for j in range(3):
        if j==0 or j==2 or i==2 or i==0:
            print("*",end="")
        else:
            print(end=" ")   
    print("")
>>>>>>> 5d09265495a18b6567dc3e4ec9e1e99d7ff969a4
