l=[]
print('list is empty:',not len(l))
