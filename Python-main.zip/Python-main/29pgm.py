d1={'name':'akhil','rollno':10,'age':21}
d2={'rollno':11,'mark1':24,'mark2':54}
d1.update(d2)
print(d1)
