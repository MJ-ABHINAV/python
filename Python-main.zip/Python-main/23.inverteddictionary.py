init_dic={'name':'Ajith','Roll No.':9,'College':'MACE','Dept':'MCA'}
inv_dic = {v: k for k, v in init_dic.items()}
print("inverse mapped dictionary : ", inv_dic)
