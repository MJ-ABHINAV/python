#!/usr/bin/env python3
a=int(input("Enter the radius:"))
print("The area of the circle is:", 3.14*a*a)
