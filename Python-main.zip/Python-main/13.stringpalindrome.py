s=input("Enter a string: ")
item=s[-1::-1]
if(s==item):
        print(s + " is Palindrome")
else:
        print (s + " is not palindrome")

