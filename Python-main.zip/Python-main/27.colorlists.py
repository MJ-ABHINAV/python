c1=set(input("Enter the color-list1: ").split(','))
c2=set(input("Enter the color-list2: ").split(','))
print("The colors present only in list1 are: ",c1-c2)
