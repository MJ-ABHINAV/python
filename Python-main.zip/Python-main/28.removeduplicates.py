i=input("Enter the list: ")
i=i.split(',')
print(set(i))
