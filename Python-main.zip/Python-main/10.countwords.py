s=input("Enter a string or line:")
l=s.split()
length=len(l)
print(s + ": " + str(length) + " " + "word")
