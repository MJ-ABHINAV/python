st=input('enter a string')
result=''
if len(st)==2:
    print(st*2)
elif len(st)<2:
    print(result)
else:
    print(st[:2]+st[-2:])

    
