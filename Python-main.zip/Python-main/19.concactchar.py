s=input('Enter characters in a comma separated list: ')
s=list(s.split(','))
item=""
for i in s:
    item=item+i
print(item)
    
    
