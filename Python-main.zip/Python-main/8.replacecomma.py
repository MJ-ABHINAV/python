s=input("Enter a string: ")
print("Output:",s.replace(',','-'))
